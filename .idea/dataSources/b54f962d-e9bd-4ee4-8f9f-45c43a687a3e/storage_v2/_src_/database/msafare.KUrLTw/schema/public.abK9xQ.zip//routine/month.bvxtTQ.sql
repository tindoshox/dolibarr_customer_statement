create function month(timestamp with time zone) returns integer
    stable
    language sql
as
$$ SELECT EXTRACT(MONTH FROM $1)::INTEGER; $$;

alter function month(timestamp with time zone) owner to postgres;

