create function update_modified_column_tms() returns trigger
    language plpgsql
as
$$ BEGIN NEW.tms = now(); RETURN NEW; END; $$;

alter function update_modified_column_tms() owner to postgres;

