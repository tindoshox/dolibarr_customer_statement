create function year(date) returns integer
    immutable
    language sql
as
$$ SELECT EXTRACT(YEAR FROM $1)::INTEGER; $$;

alter function year(date) owner to postgres;

