create function year(timestamp with time zone) returns integer
    stable
    language sql
as
$$ SELECT EXTRACT(YEAR FROM $1)::INTEGER; $$;

alter function year(timestamp with time zone) owner to postgres;

