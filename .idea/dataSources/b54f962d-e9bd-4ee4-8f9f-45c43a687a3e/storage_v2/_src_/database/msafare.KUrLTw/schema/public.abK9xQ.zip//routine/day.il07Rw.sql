create function day(timestamp with time zone) returns integer
    stable
    language sql
as
$$ SELECT EXTRACT(DAY FROM $1)::INTEGER; $$;

alter function day(timestamp with time zone) owner to postgres;

