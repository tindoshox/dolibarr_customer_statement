create function unix_timestamp(timestamp with time zone) returns bigint
    immutable
    strict
    language sql
as
$$SELECT EXTRACT(EPOCH FROM $1)::bigint;$$;

alter function unix_timestamp(timestamp with time zone) owner to postgres;

