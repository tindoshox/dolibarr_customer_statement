create function checkpoint_activity() returns trigger
    language plpgsql
as
$$
DECLARE
v_invid INT;
BEGIN
-- Get invid
v_invid := (SELECT fk_facture FROM public.llx_paiement_facture WHERE rowid =
NEW.rowid);
-- Check which kind of event which fired the trigger
    IF TG_OP = 'INSERT'
    THEN
        update public.llx_actioncomm
        set
        percent = 100, datep2 = now() where fk_element = v_invid and percent < 100 and fk_action = 11;
    end if;
RETURN NULL;
END;
$$;

alter function checkpoint_activity() owner to postgres;

