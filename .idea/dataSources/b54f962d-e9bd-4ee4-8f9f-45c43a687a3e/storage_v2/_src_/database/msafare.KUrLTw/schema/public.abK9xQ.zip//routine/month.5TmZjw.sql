create function month(timestamp without time zone) returns integer
    immutable
    language sql
as
$$ SELECT EXTRACT(MONTH FROM $1)::INTEGER; $$;

alter function month(timestamp) owner to postgres;

