create function month(date) returns integer
    immutable
    language sql
as
$$ SELECT EXTRACT(MONTH FROM $1)::INTEGER; $$;

alter function month(date) owner to postgres;

