create function update_recnum() returns trigger
    language plpgsql
as
$$

begin

  UPDATE llx_paiement
  set num_paiement  = new.num_chq
  WHERE fk_bank  = new.rowid ;
  RETURN NEW;
END
$$;

alter function update_recnum() owner to postgres;

