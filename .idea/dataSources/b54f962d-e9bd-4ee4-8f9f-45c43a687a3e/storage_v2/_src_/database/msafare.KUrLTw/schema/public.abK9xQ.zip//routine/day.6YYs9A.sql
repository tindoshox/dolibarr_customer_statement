create function day(date) returns integer
    immutable
    language sql
as
$$ SELECT EXTRACT(DAY FROM $1)::INTEGER; $$;

alter function day(date) owner to postgres;

