create function day(timestamp without time zone) returns integer
    immutable
    language sql
as
$$ SELECT EXTRACT(DAY FROM $1)::INTEGER; $$;

alter function day(timestamp) owner to postgres;

