create function paiement_activity() returns trigger
    language plpgsql
as
$$
DECLARE
v_invid INT;
BEGIN
-- Get invid
v_invid := (SELECT fk_facture FROM public.llx_paiement_facture WHERE rowid =
NEW.rowid);
-- Check which kind of event which fired the trigger
    IF TG_OP = 'INSERT'
    THEN
        UPDATE public.llx_facture
        SET
        date_lim_reglement = date(now())+30 WHERE rowid = v_invid AND date(date_lim_reglement) <= date(NOW()) +5;
       end if;
RETURN NULL;
END;
$$;

alter function paiement_activity() owner to postgres;

