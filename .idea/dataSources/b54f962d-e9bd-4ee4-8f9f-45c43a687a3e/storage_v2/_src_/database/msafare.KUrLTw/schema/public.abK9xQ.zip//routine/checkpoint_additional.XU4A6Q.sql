create function checkpoint_additional() returns trigger
    language plpgsql
as
$$
DECLARE
v_invid INT;
v_rowid INT;
BEGIN
-- Get invid
v_invid := (SELECT fk_element FROM public.llx_actioncomm WHERE "id" =
NEW."id");
-- Get last record id
v_rowid := (SELECT "id" FROM public.llx_actioncomm WHERE "id" = NEW."id");
-- Check which kind of event which fired the trigger
    IF TG_OP = 'INSERT'
    THEN
        update public.llx_actioncomm
        set
        percent = 100, datep2 = now() where fk_element = v_invid and percent < 100 and fk_action = 11 and "id" <> v_rowid;
    end if;
RETURN NULL;
END;
$$;

alter function checkpoint_additional() owner to postgres;

